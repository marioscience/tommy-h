#!/bin/sh
# Entrypoint for Standalone Windows Test

echo "[Standalone] Iniciando Oxide Control Panel..."
export STANDALONE_MODE=true
export CONFIG_PATH=/app/config/oxide_proxy.windows.yml

cd /app/node_panel
node server.js &

echo "[Standalone] Iniciando motor Oxide Proxy..."
cd /app
exec ./oxide_proxy --config /app/config/oxide_proxy.windows.yml
